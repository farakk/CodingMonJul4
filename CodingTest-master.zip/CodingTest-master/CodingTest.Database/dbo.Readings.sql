﻿CREATE TABLE [dbo].[Readings] (
    [Id]    INT             IDENTITY (1, 1) NOT NULL,
    [Depth] DECIMAL (18, 2) NOT NULL,
	[Temperature] DECIMAL (18, 2) NOT NULL,
    [MagX]  DECIMAL (18, 2) NOT NULL,
    [MagY]  DECIMAL (18, 2) NOT NULL,
    [MagZ]  DECIMAL (18, 2) NOT NULL,
	[GravX]  DECIMAL (18, 2) NOT NULL,
    [GravY]  DECIMAL (18, 2) NOT NULL,
    [GravZ]  DECIMAL (18, 2) NOT NULL,
    CONSTRAINT [PK_dbo.Readings] PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO

