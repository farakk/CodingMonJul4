namespace CodingTest.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SecondMigra : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Readings", "Temperature", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AddColumn("dbo.Readings", "MagZ", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AddColumn("dbo.Readings", "GravX", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AddColumn("dbo.Readings", "GravY", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AddColumn("dbo.Readings", "GravZ", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            DropColumn("dbo.Readings", "MaxZ");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Readings", "MaxZ", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            DropColumn("dbo.Readings", "GravZ");
            DropColumn("dbo.Readings", "GravY");
            DropColumn("dbo.Readings", "GravX");
            DropColumn("dbo.Readings", "MagZ");
            DropColumn("dbo.Readings", "Temperature");
        }
    }
}
