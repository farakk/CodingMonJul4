namespace CodingTest.Migrations
{
    using CodingTest.Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<CodingTest.DataContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "CodingTest.DataContext";
        }

        protected override void Seed(CodingTest.DataContext context)
        {
            {
                context.Readings.AddOrUpdate(i => i.Depth,
                    new Reading
                    {
                        Depth = 4,
                        Temperature = 300,
                        MagX = 7.7M,
                        MagY = 4.8M,
                        MagZ = 5.5M,
                        GravX = 4.4M,
                        GravY = 9.7M,
                        GravZ = 7.4M
                    },
                     new Reading
                     {
                         Depth = 3,
                         Temperature = 320,
                         MagX = 4.9M,
                         MagY = 5.7M,
                         MagZ = 3.9M,
                         GravX = 4.7M,
                         GravY = 9.6M,
                         GravZ = 7.1M
                     }
               );

            }


        }
    }
}
