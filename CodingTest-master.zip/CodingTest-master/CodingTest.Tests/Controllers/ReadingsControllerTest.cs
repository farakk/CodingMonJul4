﻿using CodingTest.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CodingTest.Tests.Controllers
{
    [TestClass]
    public class ReadingsControllerTest
    {

        [TestMethod]
        public async Task IndexSync()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(() => Task.FromResult(1));
            // Or: service.Setup(x => x.GetAsync()).ReturnsAsync(1);
            var system = new SystemUnderTest(service.Object);
            var result = await system.Index();
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task IndexAsync()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(async () =>
            {
                await Task.Yield();
                return 1;
            });
            var system = new SystemUnderTest(service.Object);
            var result = await system.Index();
                Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task IndexFail()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(async () =>
            {
                await Task.Yield();
                throw new Exception();
            });
            var system = new SystemUnderTest(service.Object);
            await AssertEx.ThrowsAsync(system.Index);
        }

        [TestMethod]
        public async Task CreateSync()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(() => Task.FromResult(2));
            var system = new SystemUnderTest(service.Object);
            var result = await system.Create();
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task CreateAsync()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(async () =>
            {
                await Task.Yield();
                return 2;
            });
            var system = new SystemUnderTest(service.Object);
            var result = await system.Create();
             Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task CreateFail()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(async () =>
            {
                await Task.Yield();
                throw new Exception();
            });
            var system = new SystemUnderTest(service.Object);
            await AssertEx.ThrowsAsync(system.Create);
        }

        [TestMethod]
        public async Task EditSync()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(() => Task.FromResult(3));
            var system = new SystemUnderTest(service.Object);
            var result = await system.Edit();
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task EditAsync()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(async () =>
            {
                await Task.Yield();
                return 3;
            });
            var system = new SystemUnderTest(service.Object);
            var result = await system.Edit();
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task EditFail()
        {
            var service = new Mock<IMyService>();
            service.Setup(x => x.GetAsync()).Returns(async () =>
            {
                await Task.Yield();
                throw new Exception();
            });
            var system = new SystemUnderTest(service.Object);
            await AssertEx.ThrowsAsync(system.Edit);
        }   
    }
}
