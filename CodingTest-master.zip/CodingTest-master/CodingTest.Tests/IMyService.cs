﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingTest.Tests
{
    public interface IMyService
    {
        Task<int> GetAsync();
    }
    public sealed class SystemUnderTest
    {
        private readonly IMyService _service;
        public SystemUnderTest(IMyService service)
        {
            _service = service;
        }
        public async Task<int> Index()
        {
            return await _service.GetAsync();
        }

        public async Task<int> Create()
        {
            return await _service.GetAsync();
        }

        public async Task<int> Edit()
        {
            return await _service.GetAsync();
        }
    }
}
